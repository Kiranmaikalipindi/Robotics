#include <Servo.h>

Servo scanner;

int flameSensor = A0;
int smokeSensor = A1;

int motorLeft = 5;
int motorRight = 6;
int pump = 7;

int flameValue;
int smokeValue;

int threshold = 600;   // fire detection level

void setup() {

  Serial.begin(9600);

  pinMode(motorLeft, OUTPUT);
  pinMode(motorRight, OUTPUT);
  pinMode(pump, OUTPUT);

  scanner.attach(9);

}

void loop() {

  // Read sensors
  flameValue = analogRead(flameSensor);
  smokeValue = analogRead(smokeSensor);

  Serial.print("Flame: ");
  Serial.print(flameValue);
  Serial.print("  Smoke: ");
  Serial.println(smokeValue);

  // Servo scanning
  scanner.write(40);
  delay(400);

  scanner.write(90);
  delay(400);

  scanner.write(140);
  delay(400);

  // Fire detection logic
  if(flameValue > threshold || smokeValue > threshold) {

    Serial.println("FIRE DETECTED!");

    // Stop motors
    digitalWrite(motorLeft, LOW);
    digitalWrite(motorRight, LOW);

    // Activate pump
    digitalWrite(pump, HIGH);

  }

  else {

    Serial.println("No Fire - Robot Moving");

    // Move robot
    digitalWrite(motorLeft, HIGH);
    digitalWrite(motorRight, HIGH);

    // Pump OFF
    digitalWrite(pump, LOW);
  }

  delay(200);

}